import { useState } from 'react'
import {
  ArrowRight, Users, Briefcase, Scale, FileText, Home, MapPin, Phone, Mail,
  UserCheck, HeartHandshake, MessageSquareText, Award, ChevronDown, Landmark,
} from 'lucide-react'

const NAV = ['Home', 'About', 'Practice Areas', 'Our Team', 'Testimonials', 'Contact']

const AREAS = [
  { icon: Users, title: 'Family Law', text: "Compassionate support for life's most personal matters." },
  { icon: Briefcase, title: 'Business Law', text: 'Helping businesses grow and stay protected.' },
  { icon: Scale, title: 'Criminal Defense', text: 'Skilled advocacy. Stronger defense.' },
  { icon: FileText, title: 'Personal Injury', text: "You focus on healing. We'll handle the rest." },
  { icon: Home, title: 'Real Estate Law', text: 'Smooth transactions. Secure investments.' },
]

const WHY = [
  { icon: UserCheck, title: 'Experienced Attorneys', text: 'With a proven track record' },
  { icon: HeartHandshake, title: 'Client-Focused Approach', text: 'Your goals are our priority' },
  { icon: MessageSquareText, title: 'Transparent Communication', text: 'No surprises, just honest advice' },
  { icon: Award, title: 'Results-Driven', text: 'We fight for what matters' },
]

const STATS = [
  ['15+', 'Years of Experience'],
  ['2,500+', 'Cases Successfully Handled'],
  ['98%', 'Client Satisfaction Rate'],
  ['5', 'Star Rating'],
]

const REVIEWS = [
  { name: 'Sarah M.', role: 'Family Law Client', img: '/images/avatar1.jpg',
    text: "The team at Riverton & Associates was incredible. They handled my case with professionalism, empathy and skill. I couldn't have asked for a better experience." },
  { name: 'James T.', role: 'Business Law Client', img: '/images/avatar2.jpg',
    text: 'Their attention to detail and clear communication made a stressful situation so much easier. I highly recommend them to anyone in need of legal help.' },
  { name: 'Ayesha K.', role: 'Personal Injury Client', img: '/images/avatar3.jpg',
    text: 'From the first consultation to the final verdict, I felt supported and informed. The results exceeded my expectations.' },
]

export default function App() {
  const [slide, setSlide] = useState(0)
  const [sent, setSent] = useState(false)

  return (
    <>
      <header className="nav">
        <div className="container nav-in">
          <a href="#home" className="logo">
            <Landmark size={34} strokeWidth={1.4} />
            <span><b>RIVERTON &amp; ASSOCIATES</b><small>L A W &nbsp; F I R M</small></span>
          </a>
          <nav>{NAV.map((n) => <a key={n} href={`#${n.toLowerCase().replace(/\s/g, '-')}`}>{n}</a>)}</nav>
          <a href="#contact" className="btn btn-dark btn-sm">Free Consultation</a>
        </div>
      </header>

      <section id="home" className="hero">
        <div className="container hero-in">
          <p className="eyebrow">TRUST / EXPERIENCE / RESULTS</p>
          <h1>Strong Legal Support<br />for a Brighter Future</h1>
          <p className="lead">We provide expert legal advice and representation for individuals, families and businesses. Your rights. Our priority.</p>
          <a href="#contact" className="btn btn-dark">Schedule a Free Consultation <ArrowRight size={14} /></a>
        </div>
      </section>

      <section id="practice-areas" className="areas">
        <div className="container">
          <div className="areas-head">
            <div><p className="eyebrow sm">OUR PRACTICE AREAS</p><h2>Legal Services We Offer</h2></div>
            <p className="muted">From personal matters to complex business challenges, our experienced team is here to help you navigate every step of the way.</p>
          </div>
          <div className="areas-grid">
            {AREAS.map(({ icon: Icon, title, text }) => (
              <a href="#contact" className="area" key={title}>
                <span className="icon-circle"><Icon size={22} strokeWidth={1.4} /></span>
                <h3>{title}</h3><p>{text}</p><ArrowRight size={14} />
              </a>
            ))}
          </div>
        </div>
      </section>

      <section id="about" className="about">
        <div className="container about-in">
          <div className="about-img" />
          <div className="about-text">
            <p className="eyebrow sm">ABOUT OUR FIRM</p>
            <h2>Dedicated to Justice.<br />Committed to You.</h2>
            <p>At Riverton &amp; Associates, we believe that everyone deserves fair representation. With years of experience and a client-first approach, we work tirelessly to achieve the best possible outcomes for your case.</p>
            <a href="#about" className="btn btn-dark btn-sm">Learn More <ArrowRight size={13} /></a>
          </div>
          <ul className="why">
            {WHY.map(({ icon: Icon, title, text }) => (
              <li key={title}>
                <span className="icon-circle sm"><Icon size={16} strokeWidth={1.4} /></span>
                <div><b>{title}</b><small>{text}</small></div>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="impact">
        <div className="container impact-in">
          <div><p className="eyebrow sm gold">OUR IMPACT</p><h2>Trusted by Thousands.<br />Proven by Results.</h2></div>
          <div className="stats">
            {STATS.map(([n, l]) => <div key={l}><strong>{n}</strong><span>{l}</span></div>)}
          </div>
        </div>
      </section>

      <section id="testimonials" className="reviews">
        <div className="container">
          <p className="eyebrow sm">WHAT OUR CLIENTS SAY</p>
          <h2>Real People. Real Results.</h2>
          <div className="review-grid">
            {REVIEWS.map((r, i) => (
              <figure key={r.name} className={`review ${i === slide ? 'active' : ''}`}>
                <span className="quote">&ldquo;</span>
                <blockquote>&ldquo;{r.text}&rdquo;</blockquote>
                <figcaption>
                  <img src={r.img} alt="" onError={(e) => (e.currentTarget.style.visibility = 'hidden')} />
                  <span><b>{r.name}</b><small>{r.role}</small></span>
                </figcaption>
              </figure>
            ))}
          </div>
          <div className="dots">
            {REVIEWS.map((r, i) => (
              <button key={r.name} aria-label={`Show testimonial ${i + 1}`} className={i === slide ? 'on' : ''} onClick={() => setSlide(i)} />
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="contact">
        <div className="container contact-in">
          <div className="contact-info">
            <p className="eyebrow sm gold">GET IN TOUCH</p>
            <h2>Let&rsquo;s Find the Right Solution<br />for Your Legal Needs.</h2>
            <p className="small">Contact us today for a free consultation. We&rsquo;re here to help.</p>
            <ul>
              <li><Phone size={14} />+1 (555) 129-4567</li>
              <li><Mail size={14} />hello@rivertonlaw.com</li>
              <li><MapPin size={14} />123 Justice Avenue, New York, NY 10001</li>
            </ul>
          </div>
          <form className="form" onSubmit={(e) => { e.preventDefault(); setSent(true) }}>
            <div className="row">
              <input placeholder="Full Name" required />
              <input type="email" placeholder="Email Address" required />
            </div>
            <div className="select">
              <select defaultValue="" required>
                <option value="" disabled>Select Practice Area</option>
                {AREAS.map((a) => <option key={a.title}>{a.title}</option>)}
              </select>
              <ChevronDown size={14} />
            </div>
            <textarea rows="3" placeholder="How can we help you?" />
            <button className="btn btn-gold" type="submit">{sent ? 'Message Sent' : <>Send Message <ArrowRight size={14} /></>}</button>
          </form>
        </div>
      </section>
    </>
  )
}
